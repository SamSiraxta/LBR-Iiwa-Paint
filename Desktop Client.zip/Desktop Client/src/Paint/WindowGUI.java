package Paint;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.*;
import java.io.IOException;

public class WindowGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	private static boolean bSend = false;
	private static boolean bReleased = false;

	private JPanel contentPanel;
	static int oldX, oldY, currentX, currentY;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					// Generate a title and a image cursor
					WindowGUI frame = new WindowGUI();
					frame.setTitle("Paint with Iiwa!");
					Image icon = Toolkit.getDefaultToolkit().getImage("Image\\icono.png");
					frame.setIconImage(icon);
					frame.setVisible(true);
					frame.setResizable(false);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static int getCurrentX() {
		return currentX;
	}

	public static int getCurrentY() {
		return currentY;
	}

	public static int oldX() {
		return oldX;
	}

	public static int oldY() {
		return oldY;
	}

	public static boolean isSent() {
		return bSend;
	}

	public static void setSend(boolean bValue) {
		WindowGUI.bSend = bValue;
	}

	public static boolean isReleased() {
		return bReleased;
	}

	public static boolean setReleased(boolean bValue) {
		bReleased = false;
		return WindowGUI.bReleased = bValue;
	}

	public WindowGUI() throws IOException {
		final Image customCursor = new ImageIcon("Image\\puntero2.png").getImage();
		final Point hotspot = new Point(0, 0);
		final String name = "Cursor";
		this.setCursor(getToolkit().createCustomCursor(customCursor, hotspot, name));

		DrawPad dibujo = new DrawPad();
		setIconImage(Toolkit.getDefaultToolkit().getImage("Image\\logo.jpg"));

		ImageIcon fondo = new ImageIcon("Image\\fondoresize2.png");
		ImageIcon goma = new ImageIcon("Image\\undo.png");
		ImageIcon bSendBoton = new ImageIcon("Image\\sendResize.png");

		setBackground(new Color(0, 255, 153));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 602);
		contentPanel = new JPanel();
		contentPanel.setBackground(new Color(230, 240, 240));

		setContentPane(contentPanel);
		contentPanel.setLayout(null);

		// DRAW PANEL
		JPanel panel = new JPanel();

		panel.setBackground(new Color(226, 44, 44));
		panel.setBounds(192, 39, 795, 514);
		contentPanel.add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		// EVENT TO DETECT WHEN THE MOUSE IS MOVED AROUND
		panel.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				currentX = e.getX();
				currentY = e.getY();
				dibujo.DrawLine();
				oldX = currentX;
				oldY = currentY;
			}
		});

		// EVENT TO DETECT WHEN THE MOUSE IS RELEASED
		panel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				bReleased = true;
			}
		});

		// EVENT TO DETECT WHEN THE MOUSE IS PRESSED
		panel.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				oldX = e.getX();
				oldY = e.getY();
			}
		});

		// BUTTONS
		JButton btn_green = new JButton();
		JButton btn_red = new JButton();
		JButton btn_Blue = new JButton();
		JButton btn_black = new JButton();

		btn_green.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				dibujo.green();

			}
		});
		btn_green.setBounds(40, 170, 80, 80);
		btn_green.setBackground(new Color(52, 214, 72));
		// contentPanel.add(btn_green);

		btn_red.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				dibujo.red();
			}
		});
		btn_red.setBounds(40, 285, 80, 80);
		btn_red.setBackground(new Color(226, 44, 44));
		// contentPanel.add(btn_red);

		btn_Blue.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				dibujo.blue();

			}
		});
		btn_Blue.setBounds(40, 400, 80, 80);
		btn_Blue.setBackground(new Color(72, 129, 223));
		// contentPanel.add(btn_Blue);

		btn_black.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				dibujo.black();

			}
		});
		btn_black.setBounds(50, 65, 60, 60);
		btn_black.setBackground(new Color(0, 0, 0));
		// contentPanel.add(btn_black);

		JButton btn_clear = new JButton(goma);
		btn_clear.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// CLEAN SCREEN
				dibujo.clear();

			}
		});
		btn_clear.setBounds(1040, 130, 101, 132);
		btn_clear.setContentAreaFilled(false);
		btn_clear.setOpaque(false);
		btn_clear.setBorderPainted(false);
		contentPanel.add(btn_clear);

		JPanel panel_icon = new JPanel();
		contentPanel.add(panel_icon);

		// EXTRACTING DRAWPAD ATTRIBUTES
		panel.add(dibujo);

		JButton btnbSend = new JButton(bSendBoton);
		btnbSend.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				bSend = true;
			}
		});
		btnbSend.setBounds(1040, 330, 101, 132);
		btnbSend.setContentAreaFilled(false);
		btnbSend.setOpaque(false);
		btnbSend.setBorderPainted(false);
		contentPanel.add(btnbSend);

		// BACKGROUND
		JButton btn_FONDO = new JButton(fondo);
		btn_FONDO.setBounds(0, 0, 1200, 602);
		btn_FONDO.setContentAreaFilled(false);
		btn_FONDO.setOpaque(false);
		btn_FONDO.setBorderPainted(false);
		contentPanel.add(btn_FONDO);

	}
}