package Paint;

import java.util.ArrayList;
import java.lang.Math;

public class GenerateVector {

	// Statics
	static ArrayList<Integer> vectorLINES = new ArrayList<Integer>();
	static ArrayList<Integer> vectorPTOS = new ArrayList<Integer>();

	public void Run() {

		// Point variables
		int cont_ptos, cont_lin, x, y;
		int pointX, pointY, pointAntX = 0, pointAntY = 0;

		// Booleans to Start off
		boolean bStart = false;
		boolean bClear = false;
		boolean bReleased = false;

		// Sent GenerateVector
		ArrayList<Integer> vectorX = new ArrayList<Integer>();
		ArrayList<Integer> vectorY = new ArrayList<Integer>();

		vectorX.clear();
		vectorY.clear();
		WindowGUI.setSend(false);
		bStart = false;
		cont_ptos = 0;
		cont_lin = 0;

		System.out.println("GENERATING POINTS");
		while (!bStart) {

			// Leaving the while statement
			bStart = WindowGUI.isSent();

			// Getting the X and Y values
			pointX = WindowGUI.getCurrentX();
			pointY = WindowGUI.getCurrentY();

			// Consulting the state of bReleased
			bReleased = WindowGUI.isReleased();

			if (bReleased == true) {
				bReleased = WindowGUI.setReleased(false);
				vectorLINES.add(cont_lin, cont_ptos);
				cont_lin++;

				System.out.println("Line: " + vectorLINES);
			}
			// Needed to wipe console memory
			System.out.flush();

			// Writing the vectors
			if (pointX != 0 && pointX != pointAntX && pointY != 0 && pointY != pointAntY) {
				if ((Math.abs(pointX - pointAntX) >= 5) || (Math.abs(pointY - pointAntY) >= 5)) {
					try {
						Thread.sleep(25);
					} catch (InterruptedException e) {

						e.printStackTrace();
					}
					pointAntX = pointX;
					pointAntY = pointY;

					System.out.println("POINT: " + cont_ptos + " X: " + pointAntX + " Y: " + pointAntY);

					vectorX.add(cont_ptos, pointAntX);
					vectorY.add(cont_ptos, pointAntY);
					cont_ptos++;
					bClear = DrawPad.isClear();

					if (bClear) {
						System.out.println("Reseting Vectors");
						vectorX.clear();
						vectorY.clear();
						vectorLINES.clear();
						cont_ptos = 0;
						cont_lin = 0;
						bClear = false;
						DrawPad.setClear(false);
						vectorPTOS.clear();
					}
				}
			}
		}

		// Alternate Xs and Ys on the final VECTOR
		x = 0;
		y = 0;
		for (int u = 0; u <= ((vectorX.size() * 2) - 1); u++) {
			if (u % 2 == 0) {
				vectorPTOS.add(u, vectorX.get(x));
				x++;
			} else {
				vectorPTOS.add(u, vectorY.get(y));
				y++;
			}
		}

		System.out.println("VECTOR to be sent: " + vectorPTOS);
	}

	public ArrayList<Integer> getVectorPTOS() {
		return vectorPTOS;
	}

	public ArrayList<Integer> getvectorLINES() {
		return vectorLINES;
	}
}