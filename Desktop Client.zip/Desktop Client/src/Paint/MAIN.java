package Paint;

public class MAIN {

	public static void main(String[] args) {

		// Create the graphical environment firstly
		WindowGUI.main(args);

		while (true) {
			// Generating points
			// Handling with the connection
			new GenerateVector().Run();
			// Sending data
			new SendData().Run();
		}
	}
}