package Paint;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class SendData {

	// Network Parameters
	private static String HOST = "172.31.1.147";
	private static int PORT = 30005;

	// Vectors
	static ArrayList<Integer> vectorPTOS = new ArrayList<Integer>();
	static ArrayList<Integer> vectorLINES = new ArrayList<Integer>();

	public void Run() {

		// Object variables
		GenerateVector generateVector = new GenerateVector();

		// Obtaining the vectors :D
		vectorPTOS = generateVector.getVectorPTOS();
		vectorLINES = generateVector.getvectorLINES();

		System.out.println("STARTING CLIENT APP");
		Socket socket;
		DataOutputStream message;

		try {

			// Opening socket
			socket = new Socket(HOST, PORT);
			message = new DataOutputStream(socket.getOutputStream());

			// Now I send the number of ptos
			message.write(vectorPTOS.size());

			// Now I send the POINT vector
			for (int t = 0; t < vectorPTOS.size(); t++) {
				message.write(vectorPTOS.get(t) / 4);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			// Now I send the number of lines
			message.write(vectorLINES.size());

			// Now I send the LINE vector
			for (int t = 0; t < vectorLINES.size(); t++) {
				message.write(vectorLINES.get(t));
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			// Closing socket
			socket.close();

		} catch (UnknownHostException e) {
			System.out.println("[ERROR] -> HOST UNREACHABLE!");
			WindowGUI.setSend(false);
		} catch (IOException e) {
			System.out.println("[ERROR] -> I/O misunderstanding!");
			WindowGUI.setSend(false);
		}
	}

	public static void setVectorPTOS(ArrayList<Integer> vectorPTOS) {
		SendData.vectorPTOS = vectorPTOS;
	}
}