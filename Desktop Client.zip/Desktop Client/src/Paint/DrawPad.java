package Paint;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;

import javax.swing.JPanel;

class DrawPad extends JPanel {
	private static final long serialVersionUID = 1L;
	private static boolean bClear = false;
	WindowGUI windowGUI;
	Image image;
	Graphics2D graphics2D;

	public void paintComponent(Graphics g) {
		super.paintComponents(g);

		//Recreate the image in case this is empty
		if (image == null) {
			image = createImage(getSize().width, getSize().height);
			graphics2D = (Graphics2D) image.getGraphics();
			graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			clear();
			bClear = false;
		}
		g.drawImage(image, 0, 0, null);
	}
	
	public static boolean isClear() {
		return bClear;
	}
	
	public static boolean setClear (boolean valor1) {
		bClear = false;
		return DrawPad.bClear = false;
	}

	//Draw a geometry
	public void DrawLine() {

		int oldX, oldY, currentX, currentY;
		oldX = WindowGUI.oldX();
		oldY = WindowGUI.oldY();
		currentX = WindowGUI.getCurrentX();
		currentY = WindowGUI.getCurrentY();

		if (graphics2D != null) {
			graphics2D.drawLine(oldX, oldY, currentX, currentY);
			repaint();
		}
	}

	//METHODS called in WindowGUI
	public void clear() {
		graphics2D.setPaint(Color.white);
		graphics2D.fillRect(0, 0, getSize().width, getSize().height);
		graphics2D.setPaint(Color.black);
		repaint();
		bClear = true;
	}

	public void red() {
		graphics2D.setPaint(Color.red);
		repaint();
	}

	public void black() {
		graphics2D.setPaint(Color.black);
		repaint();
	}

	public void blue() {
		graphics2D.setPaint(Color.blue);
		repaint();
	}

	public void green() {
		graphics2D.setPaint(Color.green);
		repaint();
	}
}