package paint;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectAndroid{

	void Start(int PORT) {
		// Init variables
		Socket clientSocket;
		int cont = 0, contLINES = 0, contPTOS = 0;

		PAINT.vectorPTOS.clear();
		PAINT.vectorLINES.clear();
		PAINT.vectorRAW.clear();

		try {
			// Server socket awaiting for some client request
			ServerSocket serverSocket = new ServerSocket(PORT);
			System.out.println("Server> Initialized");
			System.out.println("Server> Listening on the port: " + PORT);
			// Accept the connection
			clientSocket = serverSocket.accept();
			BufferedReader counter = new BufferedReader(new InputStreamReader(
					clientSocket.getInputStream()));
			String requestCounter = counter.readLine();
			int Amount = Integer.valueOf(requestCounter);
			// Add the total of points and lines
			PAINT.vectorRAW.add(requestCounter);

			// If greater than 980 points, buffer is overflowed
			if (Amount <= 980) {
				// Read and store data
				while (cont <= (Amount + 1)) {

					if (cont == 0) {
						System.out.println("Server> Loading data...");
					}

					clientSocket = serverSocket.accept();
					BufferedReader input = new BufferedReader(
							new InputStreamReader(clientSocket.getInputStream()));
					String request = input.readLine();
					PAINT.vectorRAW.add(request);

					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();

					}
					// Close the socket
					clientSocket.close();
					cont++;
				}

				System.out.println("VectorRAW: " + PAINT.vectorRAW);

				// PARSING DATA //
				contPTOS = Integer.valueOf(PAINT.vectorRAW.get(1));
				contLINES = Integer.valueOf(PAINT.vectorRAW.get(0))
						- Integer.valueOf(PAINT.vectorRAW.get(1));

				// Parsing PTOS
				int contAUX1 = 2;
				double aux1 = 0;
				for (int contPTO = 0; contPTO < contPTOS; contPTO++) {
					aux1 = Double.parseDouble((PAINT.StringFix(PAINT.vectorRAW
							.get(contAUX1))));
					PAINT.vectorPTOS.add(contPTO, aux1 / 4);
					contAUX1++;
				}

				System.out.println("VectorPTOS: " + PAINT.vectorPTOS);

				// Parsing LINES
				int contAUX2 = contPTOS + 3;
				int aux2 = 0;
				for (int contLINE = 0; contLINE < contLINES; contLINE++) {
					aux2 = Integer.parseInt((PAINT.StringFix(PAINT.vectorRAW
							.get(contAUX2))));
					PAINT.vectorLINES.add(contLINE, aux2);
					contAUX2++;
				}

				System.out.println("VectorLINES: " + PAINT.vectorLINES);
			}

			if (Amount >= 980) {
				System.out.println("Buffer overflowed!");
				// Close the socket
				clientSocket.close();
			}

		} catch (IOException ex) {
			PAINT.RandomPort();
			System.out.println(ex.getMessage());
		}
	}

	public void run(int portNumber) throws Exception {
		Start(portNumber);
	}
}