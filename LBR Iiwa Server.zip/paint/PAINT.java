package paint;

import javax.inject.Inject;
import com.kuka.roboticsAPI.applicationModel.RoboticsAPIApplication;
import com.kuka.roboticsAPI.conditionModel.ForceComponentCondition;
import com.kuka.roboticsAPI.conditionModel.ICallbackAction;
import com.kuka.roboticsAPI.conditionModel.ICondition;
import com.kuka.roboticsAPI.conditionModel.JointTorqueCondition;
import com.kuka.roboticsAPI.controllerModel.Controller;
import com.kuka.roboticsAPI.deviceModel.Device;
import com.kuka.roboticsAPI.deviceModel.JointEnum;
import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.roboticsAPI.geometricModel.Frame;
import com.kuka.roboticsAPI.geometricModel.ObjectFrame;
import com.kuka.roboticsAPI.geometricModel.Tool;
import com.kuka.roboticsAPI.geometricModel.World;
import com.kuka.roboticsAPI.motionModel.IMotion;
import com.kuka.roboticsAPI.motionModel.IMotionContainer;
import com.kuka.roboticsAPI.motionModel.Spline;
import com.kuka.roboticsAPI.persistenceModel.IPersistenceEngine;
import com.kuka.roboticsAPI.persistenceModel.XmlApplicationDataSource;
import com.kuka.roboticsAPI.persistenceModel.processDataModel.IProcessData;
import com.kuka.roboticsAPI.sensorModel.ForceSensorData;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKey;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyBar;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyListener;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyAlignment;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import javax.inject.Inject;
import com.kuka.common.ThreadUtil;
import com.kuka.roboticsAPI.applicationModel.RoboticsAPIApplication;
import static com.kuka.roboticsAPI.motionModel.BasicMotions.*;

import com.kuka.roboticsAPI.controllerModel.Controller;
import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.roboticsAPI.executionModel.IFiredConditionInfo;
import com.kuka.roboticsAPI.executionModel.IFiredTriggerInfo;
import com.kuka.roboticsAPI.geometricModel.CartDOF;
import com.kuka.roboticsAPI.geometricModel.Frame;
import com.kuka.roboticsAPI.geometricModel.ObjectFrame;
import com.kuka.roboticsAPI.geometricModel.Tool;
import com.kuka.roboticsAPI.geometricModel.World;
import com.kuka.roboticsAPI.geometricModel.math.CoordinateAxis;
import com.kuka.roboticsAPI.motionModel.IMotion;
import com.kuka.roboticsAPI.motionModel.IMotionContainer;
import com.kuka.roboticsAPI.motionModel.PositionHold;
import com.kuka.roboticsAPI.motionModel.SPL;
import com.kuka.roboticsAPI.motionModel.Spline;
import com.kuka.roboticsAPI.motionModel.SplineMotionCP;
import com.kuka.roboticsAPI.motionModel.SplineOrientationType;
import com.kuka.roboticsAPI.motionModel.controlModeModel.CartesianImpedanceControlMode;
import com.kuka.roboticsAPI.motionModel.controlModeModel.CartesianSineImpedanceControlMode;
import com.kuka.roboticsAPI.persistenceModel.IPersistenceEngine;
import com.kuka.roboticsAPI.persistenceModel.XmlApplicationDataSource;
import com.kuka.roboticsAPI.persistenceModel.processDataModel.IProcessData;
import com.kuka.roboticsAPI.uiModel.ApplicationDialogType;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKey;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyBar;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyListener;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyAlignment;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyEvent;
import com.sun.java_cup.internal.runtime.Scanner;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

@SuppressWarnings("unused")
public class PAINT extends RoboticsAPIApplication {
	// Global KUKA variables
	@Inject
	private LBR robot;
	private static int PORT = 30000;
	@Inject
	private Controller controller;
	private Tool tool;
	private ObjectFrame TCP;
	public Frame posAct, posUlt;
	private IProcessData escaleData;

	// Global variables
	public double escale, vectorX, vectorY, x, y, z;
	private Thread ReadForces;
	private boolean startApp = false;
	// Statics variables
	public static ArrayList<Double> vectorPTOS = new ArrayList<Double>();
	public static ArrayList<Integer> vectorLINES = new ArrayList<Integer>();
	public static ArrayList<Double> vectorAUX = new ArrayList<Double>();
	public static ArrayList<String> vectorRAW = new ArrayList<String>();
	public static ArrayList<String> StringPoints = new ArrayList<String>();

	@Override
	public void initialize() {
		// Inicialize Tool and Controller
		tool = getApplicationData().createFromTemplate("ToolGripper");
		tool.attachTo(robot.getFlange());
		TCP = tool.getFrame("/TCP");
		posAct = new Frame();
		escaleData = getApplicationData().getProcessData("ESCALA");
	}

	@Override
	public void run() {
		// Init variables
		int index_lin = 0, index_aux = 0;
		int index_pto = 0, beginning = 0, ending = 0;
		boolean x86 = false;

		// It waits for Robot Operation Mode to be on
		if (robot.getOperationMode() == com.kuka.roboticsAPI.deviceModel.OperationMode.AUT) {
			// Inicialize counters and variables
			ResetVectors();
			x86 = false;
			getLogger().info("Starting APP");
			tool.move(ptp(getApplicationData().getFrame("/HOMEPOS"))
					.setJointVelocityRel(0.15).setJointAccelerationRel(0.15));

			int answer = getApplicationUI().displayModalDialog(
					ApplicationDialogType.INFORMATION,
					"Which platform is client running on?", "Linux/Windows",
					"Android");
			switch (answer) {
			case 0:
				// Connecting to x86 device...
				try {
					connection(PORT, false);
				} catch (Exception e) {
				}
				x86 = true;
				break;
			case 1:
				// Connecting to Android device...
				try {
					connection(PORT, true);
				} catch (Exception e) {
				}
				break;
			}
			// If vectors are empty, it holds on its site
			if (vectorPTOS.size() != 0 && vectorLINES.size() != 0) {
				// Start App
				this.Read();
				ReadForces.start();
				while (!startApp){
					//Waiting to start off
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				// Estimate surface where papers are in
				if (!SearchSurface()) {
					// If PTO's not reached, it'll be the ending point
					posAct = robot.getCurrentCartesianPosition(TCP,
							getApplicationData().getFrame("/MiBasePAINT_REF"))
							.copyWithRedundancy();

					double zIni = posAct.getZ();
					posAct.setZ(zIni - 5);
					tool.move(lin(posAct));
				}
				getLogger().info("REFERENCE POINT: " + posAct);
				x = posAct.getX();
				y = posAct.getY();
				z = posAct.getZ();

				vectorAUX.clear();
				// Dividing the vector into smaller ones
				while (index_lin < (vectorLINES.size())) {
					ending = (vectorLINES.get(index_lin) * 2);
					vectorAUX.clear();
					while (index_aux < (ending - beginning)
							&& index_pto < vectorPTOS.size()) {
						if (index_pto < vectorPTOS.size()) {
							vectorAUX.add(index_aux, vectorPTOS.get(index_pto));
						}
						index_pto++;
						index_aux++;
					}
					beginning = ending;
					index_lin++;
					index_aux = 0;
					getLogger().info("Vector AUX: " + vectorAUX);
					SPL();

					// Last point is calculated
					posUlt = posAct;
					posUlt.setZ(z - 50);
					tool.move(lin(posUlt).setJointVelocityRel(0.15)
							.setJointAccelerationRel(0.15));
				}
			}
			tool.move(ptp(getApplicationData().getFrame("/HOMEPOS"))
					.setJointVelocityRel(0.15).setJointAccelerationRel(0.15));
		}
	}

	public static void RandomPort() {
		// In case of "JVM Bind Error", the port is changed
		if (PORT < 30010) {
			PORT += 1;
		}
		if (PORT >= 30010) {
			PORT -= 1;
		}
	}

	public Frame GeneratePoints(int contx, int conty) {
		vectorX = (vectorAUX.get(contx) * escale);
		vectorY = (vectorAUX.get(conty) * escale);
		// CREATE XML POINTS
		posAct.setX(x + vectorX).setY(y + vectorY).setZ(z + 3);
		return posAct;
	}

	private void SPL() {
		// Init variables
		Frame splItem = new Frame();
		// Setting counters to default values :D
		int contx = 0, conty = 1;
		StringPoints.clear();
		// GENERATE POINTS AND SPLINE MOVEMENT
		for (int j = 0; j < (vectorAUX.size() / 2); j++) {
			// Generate point
			splItem = GeneratePoints(contx, conty);
			// Increment counters 2 to 2
			contx += 2;
			conty += 2;
			vectorX = 0;
			vectorY = 0;
			// Need to store each one as a String
			StringPoints.add(splItem.toString());
		}
		SpLMove();
	}

	public void SpLMove() {
		// Matrix to spline motions
		SplineMotionCP<?>[] theList = new SplineMotionCP<?>[(vectorAUX.size() / 2)];
		Point ldpPoint = new Point();
		// SPline parameters
		double velo = 0.50;
		double acce = 0.01;
		// Force Control (Torque: 0.25Nm && Siftness: 2500)
		CartesianSineImpedanceControlMode sineMode = CartesianSineImpedanceControlMode
				.createDesiredForce(CartDOF.Z, 0.05, 2500);
		CartesianSineImpedanceControlMode.createDesiredForce(CartDOF.X, 0.05,
				2500);
		CartesianSineImpedanceControlMode.createDesiredForce(CartDOF.Y, 0.05,
				2500);
		sineMode.setMaxPathDeviation(10.0, 10.0, 1000.0, 100.0, 100.0, 100.0);
		// Convert from StringPoint to SplineMotionCP
		for (int cont = 0; cont < (vectorAUX.size() / 2); cont++) {
			Frame posKUKA = new Frame();
			// Init posKUKA
			posKUKA = robot.getCurrentCartesianPosition(TCP,
					getApplicationData().getFrame("/MiBasePAINT_REF"));
			// Set values to posKUKA
			posKUKA.setX(Double.parseDouble(ldpPoint.getX((StringPoints
					.get(cont)))));
			posKUKA.setY(Double.parseDouble(ldpPoint.getY((StringPoints
					.get(cont)))));
			posKUKA.setZ(Double.parseDouble(ldpPoint.getZ((StringPoints
					.get(cont)))));
			posKUKA.setAlphaRad(Double.parseDouble(ldpPoint.getA((StringPoints
					.get(cont)))));
			posKUKA.setBetaRad(Double.parseDouble(ldpPoint.getB((StringPoints
					.get(cont)))));
			posKUKA.setGammaRad(Double.parseDouble(ldpPoint.getC((StringPoints
					.get(cont)))));
			theList[cont] = spl(posKUKA);
		}

		// SPL movement
		Spline splMov = new Spline(theList);
		tool.move(splMov.setJointVelocityRel(velo)
				.setJointAccelerationRel(acce).setMode(sineMode));
	}

	// OPENING SOCKET
	public void connection(int numberPort, boolean mode) throws Exception {
		ResetVectors();
		// Escale set on ProcessData
		escale = escaleData.getValue();
		// Start connection
		if (mode) {
			new ConnectAndroid().run(numberPort);
		}
		if (!mode) {
			new ConnectDesktop().run(numberPort);
		}
	}

	// Correct string 'double' format
	public static String StringFix(String value) {
		if (value.indexOf(",") >= 0) {
			value = value.replace(",", ".");
		}
		return value;
	}

	public void ResetVectors() {
		vectorPTOS.clear();
		vectorRAW.clear();
		vectorLINES.clear();
		vectorAUX.clear();
		StringPoints.clear();
	}

	public boolean SearchSurface() {

		// Init variables
		boolean posReached = false;
		// Trigger variables
		IMotionContainer motionTrigger;
		IFiredConditionInfo firedInfo;

		// Generate force condition to detect colision
		ForceComponentCondition assemblyForce_inverted = new ForceComponentCondition(
				tool.getFrame("/TCP"), CoordinateAxis.Z, -2.3, -1.0);
		ICondition assemblyForce = assemblyForce_inverted.invert();

		// Movement to the Aprox position
		tool.move(ptp(getApplicationData().getFrame("/MiBasePAINT_REF/Aprox"))
				.setJointVelocityRel(0.35).setJointAccelerationRel(0.05));

		// Movement to the PTO
		motionTrigger = tool.move(ptp(
				getApplicationData().getFrame("/MiBasePAINT_REF/PTO"))
				.setJointVelocityRel(0.05).setJointAccelerationRel(0.05)
				.breakWhen(assemblyForce));
		firedInfo = motionTrigger.getFiredBreakConditionInfo();

		// Calculate point
		if (firedInfo != null) {
			getLogger().info("PTO FOUND!");
			// Obtaining the reference point
			posAct = robot.getCurrentCartesianPosition(TCP,
					getApplicationData().getFrame("/MiBasePAINT_REF"))
					.copyWithRedundancy();

			double zIni = posAct.getZ();
			posAct.setZ(zIni - 5);
			tool.move(lin(posAct));

			posReached = true;
		}

		return posReached;
	}

	public void Read() {

		ReadForces = new Thread(new Runnable() {
			@Override
			public void run() {

				// Init variables
				double torqueX, torqueY, torqueZ;

				while (!startApp) {
					// Read force in XYZ
					ForceSensorData data = robot.getExternalForceTorque(robot
							.getFlange());
					torqueY = data.getForce().getY();
					torqueX = data.getForce().getX();
					torqueZ = data.getForce().getZ();

					if (torqueX >= 5.2 || torqueY >= 5.2 || torqueZ >= 5.2) {
						startApp = true;
					}

					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}

	@Override
	public void dispose() {
		// Stop thread if app closed
		ReadForces.isInterrupted();
		super.dispose();
	}
}