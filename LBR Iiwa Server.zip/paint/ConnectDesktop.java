package paint;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectDesktop {

	void Start(int numberPort) {
		// Init variables
		int counter;
		Socket myService;
		DataInputStream inputData;
		ServerSocket socketService;
		InputStream inputStream;
		
		PAINT.vectorPTOS.clear();
		PAINT.vectorLINES.clear();

		try {
			socketService = new ServerSocket(numberPort);
			System.out.println("Listening on port: " + numberPort);
			myService = socketService.accept();
			System.out.println("Client is connected!");
			inputStream = myService.getInputStream();
			inputData = new DataInputStream(inputStream);
			// Firstly I recieved number of points
			counter = inputData.read();
			System.out.println("Number of recieved points: " + counter / 2);

			// Avoid an overflow due to amounts greater than 980 points
			if (counter <= 980) {
				// VECTOR OF POINTS
				for (int i = 0; i < counter; i++) {
					PAINT.vectorPTOS.add(i, (double) (inputData.read() * 2));
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println("Vector PTOS: " + PAINT.vectorPTOS);
				
				// Now I recieved number of lines
				counter = inputData.read();
				System.out.println("Number of recieved lines: " + counter);
				// Getting the Lines vector
				for (int i = 0; i < counter; i++) {
					PAINT.vectorLINES.add(i, inputData.read());
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println("Vector LINES: " + PAINT.vectorLINES);
				
				// CLOSING THE SOCKET
				try {

					myService.close();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		} catch (IOException ex) {
			PAINT.RandomPort();
			System.out.println("SOCKET ERROR");
		}
	}

	public void run(int portNumber) throws Exception {
		Start(portNumber);
	}
}
