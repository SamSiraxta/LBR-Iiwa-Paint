package paint;

public class Point {

	// Values of a ledissonPoint
	static String X, Y, Z, A, B, C;

	public String getX(String value) {
		return getter(value, "X", 3);
	}

	public String getY(String value) {
		return getter(value, "Y", 3);
	}

	public String getZ(String value) {
		return getter(value, "Z", 3);
	}

	public String getA(String value) {
		return getter(value, "A", 3);
	}

	public String getB(String value) {
		return getter(value, "B", 3);
	}

	public String getC(String value) {
		return getter(value, "C", 2);
	}

	private String getter(String value, String letter, int length) {
		int ini, start, end;
		boolean leave = false;

		ini = value.indexOf(letter);
		ini += 2;
		start = ini;
		end = ini + 1;
		while (!leave) {
			if (value.substring(start, end) != ".") { leave = true; }
			end++;
			start++;
		}
		end += length;
		return value.substring(ini, end);
	}
}