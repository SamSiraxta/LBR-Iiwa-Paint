﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Threading;

namespace FingerPaint
{
    public class AsynchronousClient
    {
        // Vectors to be sent
        static List<float> vectorX = new List<float>();
        static List<float> vectorY = new List<float>();
        static List<float> vectorPTOS = new List<float>();
        static List<int> vectorLINES = new List<int>();
        private static String HOST = MainActivity.IPAddress();
        //private static String HOST = "172.31.1.100";

        static void Send(String server, String message)
        {
            // Create a TcpClient.
            // Note, for this client to work you need to have a TcpServer 
            // connected to the same address as specified by the server, port
            // combination
            string puerto = MainActivity.PortAddress();
            Int32 port = Int32.Parse(puerto);
            //int port = 3005;
            Console.Write("port: " + port);
            TcpClient client = new TcpClient(server, port);

            // Translate the passed message into ASCII and store it as a Byte array
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);
            NetworkStream stream = client.GetStream();

            // Send the message to the connected TcpServer
            stream.Write(data, 0, data.Length);

            Console.WriteLine("Sent: {0}", message);

            // Close everything
            stream.Close();
            client.Close();
        }

        private static void AlternateVectors()
        {
            // Alternating the Xs and Ys in a final vector
            int x = 0;
            int y = 0;
            vectorPTOS.Clear();
            for (int u1 = 0; u1 <= ((vectorX.Count * 2) - 1); u1++)
            {
                if (u1 % 2 == 0)
                {
                    vectorPTOS.Add(vectorX[x]);
                    x++;
                    Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "vectorPTOS[u1]", vectorPTOS[u1].ToString());
                }
                else
                {
                    vectorPTOS.Add(vectorY[y]);
                    y++;
                    Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "vectorPTOS[u1]", vectorPTOS[u1].ToString());
                }
            }
        }

        public static int Main()
        {
            vectorX = FingerPaint.FingerPaintCanvasView.VectorX;
            vectorY = FingerPaint.FingerPaintCanvasView.VectorY;
            vectorLINES = FingerPaint.FingerPaintCanvasView.VectorLINES;

            AlternateVectors();

            // SENDING DATA //

            // Firstly I send the size of the RAW vector
            Send(HOST, (vectorPTOS.Count + vectorLINES.Count).ToString());

            Thread.Sleep(10);

            // Secondly I send the amount of points
            Send(HOST, (vectorPTOS.Count).ToString());

            Thread.Sleep(10);

            // Thirdly I send points one by one
            for (int cont = 0; cont < vectorPTOS.Count; cont++)
            {
                Send(HOST, vectorPTOS[cont].ToString());
                Thread.Sleep(10);
            }

            // Now I send the amount of lines
            Send(HOST, vectorLINES.Count.ToString());

            // Finally I send lines one by one
            for (int cont1 = 0; cont1 < vectorLINES.Count; cont1++)
            {
                Send(HOST, vectorLINES[cont1].ToString());
                Thread.Sleep(10);
            }

            return 0;
        }
    }
}