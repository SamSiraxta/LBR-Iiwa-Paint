﻿using System;
using Android.App;
using Android.Graphics;
using Android.Widget;
using Android.OS;
using Android.Content.PM;
using Android.Text;

namespace FingerPaint
{
    [Activity(Label = "Paint With Iiwa", MainLauncher = true, Icon = "@drawable/icon", ScreenOrientation = ScreenOrientation.Landscape)]
    public class MainActivity : Activity
    {
        FingerPaintCanvasView fingerPaintCanvasView;
        private static String IpTEXT;
        private static String PortTEXT;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set the view from the Main.axml layout resource
            SetContentView(Resource.Layout.Main);

            // Get a reference to the FingerPaintCanvasView from the Main.axml file
            fingerPaintCanvasView = FindViewById<FingerPaintCanvasView>(Resource.Id.canvasView);

            // Set up the Send button
            Button sendButton = FindViewById<Button>(Resource.Id.sendButton);
            sendButton.Click += OnSendButtonClick;

            // Set up the Clear button
            Button clearButton = FindViewById<Button>(Resource.Id.clearButton);
            clearButton.Click += OnClearButtonClick;
        }

        void OnClearButtonClick(object sender, EventArgs args)
        {
            fingerPaintCanvasView.ClearAll();
        }

        void OnSendButtonClick(object sender, EventArgs args)
        {
            int maximo = 15;
            EditText conectarip = FindViewById<EditText>(Resource.Id.IpString);
            conectarip.SetFilters(new IInputFilter[] { new InputFilterLengthFilter(maximo) });
            string IPAddress = conectarip.Text;
            maximo = IPAddress.Length;
            EditText conectarPort = FindViewById<EditText>(Resource.Id.PortString);
            string PortAddress = conectarPort.Text;
            PortTEXT = PortAddress;
            IpTEXT = IPAddress;
            Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, " IP", "Ip Address" + '"' + IPAddress + '"' + "Port" + PortAddress + "           " + maximo);

            AsynchronousClient.Main();
        }


        public static string IPAddress()
        {
            return IpTEXT;
        }

        public static void SetIP(string value)
        {
            IpTEXT = value;
        }

        public static string PortAddress()
        {
            return PortTEXT;
        }

        public static void SetPort(string value)
        {
            PortTEXT = value;
        }
    }
}

