using System.Collections.Generic;
using Android.Content;
using Android.Util;
using Android.Views;
using Android.Graphics;
using System;

namespace FingerPaint
{ 
       public class FingerPaintCanvasView : View
       
       {
        // Two collections for storing polylines
        Dictionary<int, FingerPaintPolyline> inProgressPolylines = new Dictionary<int, FingerPaintPolyline>();
        List<FingerPaintPolyline> completedPolylines = new List<FingerPaintPolyline>();

        // Vectors to be sent
        static List<float> vectorX = new List<float>();
        static List<float> vectorY = new List<float>();
        static List<int> vectorLINES = new List<int>();

        Paint paint = new Paint();

        public FingerPaintCanvasView(Context context) : base(context)
        {
            Initialize();
        }

        public FingerPaintCanvasView(Context context, IAttributeSet attrs) :
            base(context, attrs)
        {
            Initialize();
        }

        void Initialize()
        {
        }

        // External interface accessed from MainActivity
        public Color StrokeColor { set; get; } = Color.Red;
        public float StrokeWidth { set; get; } = 2;

        // Encapsuled vectors
        public static List<float> VectorX { get => vectorX; set => vectorX = value; }
        public static List<float> VectorY { get => vectorY; set => vectorY = value; }
        public static List<int> VectorLINES { get => vectorLINES; set => vectorLINES = value; }
        new public static double X { get => x; set => x = value; }
        new public static double Y { get => y; set => y = value; }

        public static double x, y;
        public static int contPTOS=0;

        public void ClearAll()
        {
            completedPolylines.Clear();
            Invalidate();
            contPTOS = 0;
            vectorX.Clear();
            vectorY.Clear();
            vectorLINES.Clear();
        }

        // Overrides
        public override bool OnTouchEvent(MotionEvent args)
        {
            // Get the pointer index
            int pointerIndex = args.ActionIndex;

            // Get the id to identify a finger over the course of its progress
            int id = args.GetPointerId(pointerIndex);

            // Use ActionMasked here rather than Action to reduce the number of possibilities
            switch (args.ActionMasked)
            {
                case MotionEventActions.Down:
                case MotionEventActions.PointerDown:

                    // Create a Polyline, set the initial point, and store it
                    FingerPaintPolyline polyline = new FingerPaintPolyline
                    {
                        Color = StrokeColor,
                        StrokeWidth = StrokeWidth
                    };

                    polyline.Path.MoveTo(args.GetX(pointerIndex),
                                         args.GetY(pointerIndex));

                    inProgressPolylines.Add(id, polyline);
                    break;

                case MotionEventActions.Move:

                    // Multiple Move events are bundled, so handle them differently
                    for (pointerIndex = 0; pointerIndex < args.PointerCount; pointerIndex++)
                    {
                        id = args.GetPointerId(pointerIndex);

                        inProgressPolylines[id].Path.LineTo(args.GetX(pointerIndex),
                                                            args.GetY(pointerIndex));

                        // Get the Xs and Ys of each point
                        x = args.GetX(pointerIndex);
                        y = args.GetY(pointerIndex);
                      
                            vectorX.Add((float)x);
                            vectorY.Add((float)y);
                            Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "PTO", "PTO: " + contPTOS + " X: " + vectorX[contPTOS] + " Y: " + vectorY[contPTOS]);
                            contPTOS++;
                    }
                    break;

                case MotionEventActions.Up:
                case MotionEventActions.Pointer1Up:

                    inProgressPolylines[id].Path.LineTo(args.GetX(pointerIndex),
                                                        args.GetY(pointerIndex));

                    // Add the point which the cursor is released in
                    vectorLINES.Add(contPTOS);
                    Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "vectorLINES", "vectorLINES: " + contPTOS);

                    // Transfer the in-progress polyline to a completed polyline
                    completedPolylines.Add(inProgressPolylines[id]);
                    inProgressPolylines.Remove(id);
                    break;

                case MotionEventActions.Cancel:
                    inProgressPolylines.Remove(id);
                    break;
            }
        
            // Invalidate to update the view
            Invalidate();

            // Request continued touch input
            return true;
        }

        protected override void OnDraw(Canvas canvas)
        {
            base.OnDraw(canvas);

            // Clear canvas to white
            paint.SetStyle(Paint.Style.Fill);
            paint.Color = Color.White;
            canvas.DrawPaint(paint);

            // Draw strokes
            paint.SetStyle(Paint.Style.Stroke);
            paint.StrokeCap = Paint.Cap.Round;
            paint.StrokeJoin = Paint.Join.Round;

            // Draw the completed polylines
            foreach (FingerPaintPolyline polyline in completedPolylines)
            {
                paint.Color = polyline.Color;
                paint.StrokeWidth = polyline.StrokeWidth;
                canvas.DrawPath(polyline.Path, paint);
            }

            // Draw the in-progress polylines
            foreach (FingerPaintPolyline polyline in inProgressPolylines.Values)
            {
                paint.Color = polyline.Color;
                paint.StrokeWidth = polyline.StrokeWidth;
                canvas.DrawPath(polyline.Path, paint);
            }
        }
    }
}